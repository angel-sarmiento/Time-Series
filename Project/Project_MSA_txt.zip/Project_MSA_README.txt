Data List: Project-MSA
Data Updated: 2020-01-24

FRED (Federal Reserve Economic Data)
Link: https://fred.stlouisfed.org
Help: https://fred.stlouisfed.org/help-faq
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
SMU06310800000000001                                                  

Title
----------------------------------------------------------------------
All Employees: Total Nonfarm in Los Angeles-Long Beach-Anaheim, CA    
(MSA)                                                                 

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU06310800500000003                                                  

Title
----------------------------------------------------------------------
Average Hourly Earnings of All Employees: Total Private in Los        
Angeles-Long Beach-Anaheim, CA (MSA)                                  

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Hour                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



