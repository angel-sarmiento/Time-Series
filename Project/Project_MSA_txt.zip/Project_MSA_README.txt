Data List: Project-MSA
Data Updated: 2020-01-24

FRED (Federal Reserve Economic Data)
Link: https://fred.stlouisfed.org
Help: https://fred.stlouisfed.org/help-faq
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
SMU06310800000000001                                                  

Title
----------------------------------------------------------------------
All Employees: Total Nonfarm in Los Angeles-Long Beach-Anaheim, CA    
(MSA)                                                                 

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU06310800500000003                                                  

Title
----------------------------------------------------------------------
Average Hourly Earnings of All Employees: Total Private in Los        
Angeles-Long Beach-Anaheim, CA (MSA)                                  

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Hour                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12331000000000001A                                                 

Title
----------------------------------------------------------------------
All Employees: Total Nonfarm in Miami-Fort Lauderdale-West Palm Beach,
FL (MSA)                                                              

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Annual                                                                

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12331000500000003                                                  

Title
----------------------------------------------------------------------
Average Hourly Earnings of All Employees: Total Private in Miami-Fort 
Lauderdale-West Palm Beach, FL (MSA)                                  

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Hour                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12331000500000011                                                  

Title
----------------------------------------------------------------------
Average Weekly Earnings of All Employees: Total Private in Miami-Fort 
Lauderdale-West Palm Beach, FL (MSA)                                  

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Week                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12331000600000001                                                  

Title
----------------------------------------------------------------------
All Employees: Goods Producing in Miami-Fort Lauderdale-West Palm     
Beach, FL (MSA)                                                       

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



